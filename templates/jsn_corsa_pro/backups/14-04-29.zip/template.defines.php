<?php
/**
 * @author    JoomlaShine.com http://www.joomlashine.com
 * @copyright Copyright (C) 2008 - 2011 JoomlaShine.com. All rights reserved.
 * @license   GNU/GPL v2 http://www.gnu.org/licenses/gpl-2.0.html
 */

// No direct access
defined('_JEXEC') or die('Restricted index access');

// Define template name
$JoomlaShine_Template_Name = 'Corsa';

// Define template edition
$JoomlaShine_Template_Edition = 'PRO UNLIMITED';

// Define template version
$JoomlaShine_Template_Version = '1.0.1';
